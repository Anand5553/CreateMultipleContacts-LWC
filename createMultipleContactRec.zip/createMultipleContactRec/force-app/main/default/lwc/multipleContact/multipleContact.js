import { api, LightningElement, track, wire } from 'lwc';
import { getPicklistValues,getObjectInfo } from 'lightning/uiObjectInfoApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import saveMultipleContacts from '@salesforce/apex/addMultipleRecordController.saveMultipleContacts';
import { CloseActionScreenEvent } from 'lightning/actions'; // ❗This is missing in your code


import GENDER_INDENTITY_FIELD from '@salesforce/schema/Contact.GenderIdentity';
import CONTACT_OBJECT from '@salesforce/schema/Contact';

export default class MultipleContact extends LightningElement {
    @api recordId;
    @track contacts = [];
    isLoading = false;

    @wire(getObjectInfo, { objectApiName: CONTACT_OBJECT })
    contactObjectInfo;
    /*
    THis above holds obj and metadata like
    {
  data: {
    apiName: "Contact",
    label: "Contact",
    labelPlural: "Contacts",
    keyPrefix: "003",
    recordTypeInfos: {
      "012000000000000AAA": {
        name: "Master",
        recordTypeId: "012000000000000AAA",
        available: true,
        defaultRecordTypeMapping: true,
        // More info about this record type
      },
      "012XXXXXXXXXXXXXXX": {
        // info about other record types, if any
      }
    },
    fields: {
      // Metadata about all fields on Contact, like data types, labels, etc.
      FirstName: { label: "First Name", dataType: "String", ... },
      GenderIdentity: { label: "Gender Identity", dataType: "Picklist", ... },
      // etc.
    },
    // Other metadata like child relationships, layout info, etc.
  },
  error: undefined // or error info if fetching fails
}

    */

    @wire(getPicklistValues, { recordTypeId: '$contactObjectInfo.data.defaultRecordTypeId', fieldApiName: GENDER_INDENTITY_FIELD })
    genderPickListValues;
    /*
    This holds like 
    {
  data: {
    values: [
      { label: "Male", value: "Male" },
      { label: "Female", value: "Female" },
      { label: "Non-Binary", value: "Non-Binary" },
      // ...other picklist values
    ],
    controllerValues: null, // for dependent picklists, else null
    sorted: true,          // whether values are sorted
  },
  error: undefined // or error info if something went wrong
}
    */


    get getGenderPickListValues() {
        return this.genderPickListValues?.data?.values; //if null comes at this.genderPickListValues it wont go to right f any part of the chain is null or undefined, it will gracefully return undefined without throwing an error.
        //if (This is the same as writing:
        //   this.genderPickListValues !== null &&
        //   this.genderPickListValues !== undefined &&
        //   this.genderPickListValues.data !== null &&
        //   this.genderPickListValues.data !== undefined
        // ) {
        //   return this.genderPickListValues.data.values;
        // } else {
        //   return undefined;
        // }

    }

    elementChangeHandler(event) {
        let contactRow = this.contacts.find(a => a.tempId == event.target.dataset.tempId);
        if (contactRow) {
            contactRow[event.target.name] = event.target?.value;
        }
    }

    connectedCallback() {
        this.addNewClickHandler();
    }
    addNewClickHandler(event) {
        this.contacts.push({ tempId: Date.now() });
    }
    handleDelete(event) {
        if (this.contacts.length == 1) {
            this.showToast('You cannot delete last item');
            return;
        }
        let tempId = event.target?.dataset.tempId; //gives on which row user clicked the delete button
        this.contacts = this.contacts.filter(a => a.tempId != tempId); //to remove the item i m using filter returns all the item except that which is clicked to delete

    }

    async submitClickHandler(event) {
        const allValid = this.checkControlsValidity();
        if (allValid) {
            this.isLoading = true;
            this.contacts.forEach(a => a.AccountId = this.recordId);
            let response = await saveMultipleContacts({ contacts: this.contacts });
            if (response.isSuccess) {
                this.showToast('Contacts saved successfully', 'Success', 'success');
                this.dispatchEvent(new CloseActionScreenEvent()); //close the popup after success
            }
            else {
                this.showToast('Something went wrong while saving contacts - ' + response.message);
            }
            this.isLoading = false;
        }
        else {
            this.showToast('Please correct below errors to proceed further.');
        }
    }

    checkControlsValidity() {
        let isValid = true,
        controls = this.template.querySelectorAll('lightning-input,lightning-combobox');

        controls.forEach(field => {
            if (!field.checkValidity()) {
                field.reportValidity();
                isValid = false;
            }
        });
        return isValid;
    }
    showToast(message, title = 'Error', variant = 'error') {
        const event = new ShowToastEvent({
            title,
            message,
            variant
        });
        this.dispatchEvent(event);
    }
}